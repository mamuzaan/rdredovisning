from django.apps import AppConfig


class RedovisningConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'redovisning'
